<?php

function greskaURadu($tekstGreske) {
  echo $tekstGreske;
  exit(1);
}

 ?>
